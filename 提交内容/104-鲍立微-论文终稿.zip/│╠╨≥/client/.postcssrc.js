module.exports = {
  "plugins": {
    "autoprefixer": {}
  }
}
