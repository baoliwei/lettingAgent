module.exports = {
    "root": true,
    "env": {
      "node": true
    },
    "extends": [
      "@anejs/vue/lib/base"
    ],
    "parserOptions": {
      "parser": "babel-eslint"
    }
}
