import Body from './src/body.vue'

Body.install = function (Vue) {
  Vue.component(Body.name, Body)
}

export default Body
