import Sidebar from './src/sidebar.vue'

Sidebar.install = function (Vue) {
  Vue.component(Sidebar.name, Sidebar)
}

export default Sidebar
