export default {
  name: '房源管理',
  icon: 'el-icon-menu',
  index: 2,
  key: '2-house',
  path: '/house/list',
  rule: '',
}
