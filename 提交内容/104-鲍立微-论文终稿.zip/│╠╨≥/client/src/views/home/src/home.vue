<template>
  <h1>欢迎进入房产中介管理信息系统</h1>
</template>
