export default {
  name: '首页',
  icon: 'el-icon-menu',
  index: 1,
  key: '1-home',
  path: '/',
  rule: '',
}
