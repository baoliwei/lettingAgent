export default {
  name: '出租管理',
  icon: 'el-icon-menu',
  index: 3,
  key: '3-lease',
  path: '/lease/list',
  rule: '',
}
