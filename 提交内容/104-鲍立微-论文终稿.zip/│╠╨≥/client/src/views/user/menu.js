export default {
  name: '用户管理',
  icon: 'el-icon-menu',
  index: 5,
  key: '5-user',
  path: '/user/list',
  rule: '',
}
