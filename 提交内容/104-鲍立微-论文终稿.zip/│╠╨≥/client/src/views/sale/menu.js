export default {
  name: '出售管理',
  icon: 'el-icon-menu',
  index: 4,
  key: '4-sale',
  path: '/sale/list',
  rule: '',
}
