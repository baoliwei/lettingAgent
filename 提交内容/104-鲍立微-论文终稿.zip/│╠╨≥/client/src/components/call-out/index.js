import RcCallout from './src/call-out.vue'

RcCallout.install = function (Vue) {
  Vue.component(RcCallout.name, RcCallout)
}

export default RcCallout
