import CardFooter from './src/card.footer.vue'

CardFooter.install = function (Vue) {
  Vue.component(CardFooter.name, CardFooter)
}

export default CardFooter
