import FromItemInput from './src/form.item.content.vue'

FromItemInput.install = function (Vue) {
  Vue.component(FromItemInput.name, FromItemInput)
}

export default FromItemInput
