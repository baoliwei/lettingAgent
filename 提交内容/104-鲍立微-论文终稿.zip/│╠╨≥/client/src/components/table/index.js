import Table from './src/table.js'

Table.install = function (Vue) {
  Vue.component(Table.name, Table)
}

export default Table
