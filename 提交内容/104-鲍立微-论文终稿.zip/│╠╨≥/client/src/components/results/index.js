import Results from './src/results.vue'

Results.install = function (Vue) {
  Vue.component(Results.name, Results)
}

export default Results
