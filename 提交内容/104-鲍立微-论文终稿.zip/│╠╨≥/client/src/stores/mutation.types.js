// 默认进入路由 加载中loading 遮罩
export const UPDATE_LOADING = 'UPDATE_LOADING'
// 第一次进入加载loading 设置状态 别的时候 不加载loading
export const SET_FIRST_LOADING_STATE = 'SET_FIRST_LOADING_STATE'

// 插入一个新的tab
export const TABS_ADD_TAB = 'TABS_ADD_TAB'
// 选中一个 tab
export const CURRENT_TAB = 'CURRENT_TAB'
// 删除一个 tab
export const DELETE_TAB = 'DELETE_TAB'
// 工具栏操作tabs
export const TABS_TOOLS_COMMAND = 'TABS_TOOLS_COMMAND'
